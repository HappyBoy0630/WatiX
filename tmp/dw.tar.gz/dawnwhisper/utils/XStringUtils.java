package dawnwhisper.utils;

import java.util.regex.Pattern;

import dawnwhisper.finder.XProperty;

public class XStringUtils {
	
	public static final boolean matchOrEquals(String value,String mpattern){
		if(value == null || value.equals("") || mpattern == null) return false;
		if(value.equalsIgnoreCase(mpattern)) return true;
		
		return Pattern.compile(mpattern).matcher(value).find();
	}
	
	public static final boolean matchOrEquals(XProperty xp,String realvalue){
		if(xp != null && xp.value != null && realvalue != null){
			if(xp.matchType == XProperty.PATTERN)
				return Pattern.compile(xp.value).matcher(realvalue).find();
			else if(xp.matchType == XProperty.FULLMATCH)
				return xp.value.equalsIgnoreCase(realvalue);
			else
				return realvalue.toLowerCase().contains(xp.value.toLowerCase());
		}
		
		return false;
	}
	
}
