package dawnwhisper.ws;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;

import dawnwhisper.finder.DefaultFindRule;
import dawnwhisper.finder.IFindRule;
import dawnwhisper.finder.IObjectFinder;
import dawnwhisper.finder.XProperty;
import dawnwhisper.widget.AbstractWidget;
import fonddream.util.ios.JdomHelper;
import fonddream.util.log.LogManager;

public class WidgetMap<T> {
    private IObjectFinder<T> finder = null;
    private HashMap<String,Element> widgetsE = new HashMap<String,Element>();
    private HashMap<String,AbstractWidget<T>> WIDGETS = new HashMap<String,AbstractWidget<T>>();
    
    public WidgetMap(IObjectFinder<T> finder,String file){
        this.finder = finder;
        load(file);
    }
    
    public WidgetMap(IObjectFinder<T> finder,Document doc){
        this.finder = finder;
        load(doc);
    }
    
    public void refreshMap(){
    	WIDGETS.clear();
    }
    
    public AbstractWidget<T> getWidget(String id){
        
        if(WIDGETS.containsKey(id)){
            return WIDGETS.get(id);
        }
        
        Element we = widgetsE.get(id);
        if(we == null){
            return null;
        }
        
        AbstractWidget<T> w = getWidget(we,false);
        
        WIDGETS.put(id, w);
        
        return w;
    }
    
    public AbstractWidget<T> getWidget(IFindRule findRule){
    	return new AbstractWidget<T>(finder,findRule);
    }
    
    public AbstractWidget<T> getWidget(Element we,boolean mapped){
        if(we == null) return null;
        Element pe = we.getChild("property");
        Element parente = we.getChild("parent").getChild("Widget");
        
        List<XProperty> propsl = new ArrayList<XProperty>();

        for(Object po : pe.getAttributes()){
            Attribute a = (Attribute)po;
            XProperty xp = new XProperty(getPropName(a.getName()),pe.getAttributeValue(a.getName()));
            propsl.add(xp);
        }
        
        AbstractWidget<T> w = null;
        if(parente == null){
        	w = new AbstractWidget<T>(finder,new DefaultFindRule(propsl.toArray(new XProperty[0])));
        }else{
            AbstractWidget<T> pw = getWidget(parente,mapped);
            w = new AbstractWidget<T>(pw,new DefaultFindRule(propsl.toArray(new XProperty[0])));
        }
        
        LogManager.getInstance().logDebug("AbstractWidgetMap.getWidget return : " + w);
        
        return w;
    }
    
    private String getPropName(String pn){
        if(pn.charAt(pn.length() - 1) == '.'){
            return "." + pn.substring(0, pn.length() - 1);
        }
        return pn;
    }
    
    private void load(String file){
        try {
			Document doc = JdomHelper.read(file);
			load(doc);
		} catch (Exception e) {
			LogManager.getInstance().logError("AbstractWidgetMap load widget config error." + e.getMessage());
		}
    }
    
    @SuppressWarnings("rawtypes")
	private void load(Document doc){
        
        List el = doc.getRootElement().getChildren();
        
        for(Object o : el){
            Element we = (Element)o;
            widgetsE.put(we.getAttributeValue("id"), we);
        }
        
    }
}
