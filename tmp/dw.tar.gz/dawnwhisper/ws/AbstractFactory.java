package dawnwhisper.ws;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import dawnwhisper.finder.IFactory;
import dawnwhisper.finder.IFindRule;
import dawnwhisper.finder.IObjectFinder;
import dawnwhisper.widget.AbstractWidget;
import dawnwhisper.widget.IBrowser;
import dawnwhisper.widget.ITestObj;
import dawnwhisper.widget.interfaces.IButton;
import dawnwhisper.widget.interfaces.ICheckBox;
import dawnwhisper.widget.interfaces.IComboBox;
import dawnwhisper.widget.interfaces.IDialog;
import dawnwhisper.widget.interfaces.IFileOpenDialog;
import dawnwhisper.widget.interfaces.IFileSaveDialog;
import dawnwhisper.widget.interfaces.ILabel;
import dawnwhisper.widget.interfaces.IList;
import dawnwhisper.widget.interfaces.IMenuBar;
import dawnwhisper.widget.interfaces.IOptionPaneDialog;
import dawnwhisper.widget.interfaces.IPopupMenu;
import dawnwhisper.widget.interfaces.IProgressBar;
import dawnwhisper.widget.interfaces.IRadioButton;
import dawnwhisper.widget.interfaces.IScrollBar;
import dawnwhisper.widget.interfaces.ITabbedPane;
import dawnwhisper.widget.interfaces.ITable;
import dawnwhisper.widget.interfaces.ITextArea;
import dawnwhisper.widget.interfaces.ITextField;
import dawnwhisper.widget.interfaces.IToggleButton;
import dawnwhisper.widget.interfaces.ITree;
import dawnwhisper.widget.interfaces.ITreeTable;
import dawnwhisper.widget.interfaces.IWidget;
import fonddream.util.log.LogManager;

public abstract class AbstractFactory<T> implements IFactory{
	
	@Override
	public IButton button(IFindRule ... findRule) {
		return (IButton) create(getInterfaceClass(IButton.class.getName()),
				findRule);
	}

	@Override
	public ITextField textField(IFindRule ... findRule) {
		return (ITextField) create(
				getInterfaceClass(ITextField.class.getName()), findRule);
	}

	@Override
	public ITextArea textArea(IFindRule ... findRule) {
		return (ITextArea) create(getInterfaceClass(ITextArea.class.getName()),
				findRule);
	}

	@Override
	public ICheckBox checkBox(IFindRule ... findRule) {
		return (ICheckBox) create(getInterfaceClass(ICheckBox.class.getName()),
				findRule);
	}

	@Override
	public IComboBox comboBox(IFindRule ... findRule) {
		return (IComboBox) create(getInterfaceClass(IComboBox.class.getName()),
				findRule);
	}

	@Override
	public IDialog dialog(IFindRule ... findRule) {
		return (IDialog) create(getInterfaceClass(IDialog.class.getName()),
				findRule);
	}

	@Override
	public IList list(IFindRule ... findRule) {
		return (IList) create(getInterfaceClass(IList.class.getName()),
				findRule);
	}

	@Override
	public IMenuBar menuBar(IFindRule ... findRule) {
		return (IMenuBar) create(getInterfaceClass(IMenuBar.class.getName()),
				findRule);
	}

	@Override
	public IPopupMenu popupMenu(IFindRule ... findRule) {
		return (IPopupMenu) create(
				getInterfaceClass(IPopupMenu.class.getName()), findRule);
	}

	@Override
	public IProgressBar progressBar(IFindRule ... findRule) {
		return (IProgressBar) create(
				getInterfaceClass(IProgressBar.class.getName()), findRule);
	}

	@Override
	public IScrollBar scrollBar(IFindRule ... findRule) {
		return (IScrollBar) create(
				getInterfaceClass(IScrollBar.class.getName()), findRule);
	}

	@Override
	public ITabbedPane tabbedPane(IFindRule ... findRule) {
		return (ITabbedPane) create(
				getInterfaceClass(ITabbedPane.class.getName()), findRule);
	}

	@Override
	public ITable table(IFindRule ... findRule) {
		return (ITable) create(getInterfaceClass(ITable.class.getName()),
				findRule);
	}

	@Override
	public ITree tree(IFindRule ... findRule) {
		return (ITree) create(getInterfaceClass(ITree.class.getName()),
				findRule);
	}

	@Override
	public ITreeTable treeTable(IFindRule ... findRule) {
		return (ITreeTable) create(
				getInterfaceClass(ITreeTable.class.getName()), findRule);
	}

	@Override
	public IOptionPaneDialog optionPaneDialog(IFindRule ... findRule) {
		return (IOptionPaneDialog) create(
				getInterfaceClass(IOptionPaneDialog.class.getName()), findRule);
	}

	@Override
	public IToggleButton toggleButton(IFindRule ... findRule) {
		return (IToggleButton) create(
				getInterfaceClass(IToggleButton.class.getName()), findRule);
	}

	@Override
	public IRadioButton radioButton(IFindRule ... findRule) {
		return (IRadioButton) create(
				getInterfaceClass(IRadioButton.class.getName()), findRule);
	}

	@Override
	public ILabel label(IFindRule ... findRule) {
		return (ILabel) create(getInterfaceClass(ILabel.class.getName()),
				findRule);
	}

	@Override
	public ILabel getLabel(String id) {
		return (ILabel)getObject(id, ILabel.class.getName());
	}
	
    @Override
    public IToggleButton getToggleButton(String id) {
        return (IToggleButton)getObject(id, IToggleButton.class.getName());
    }

    @Override
    public IButton getButton(String id) {
        return (IButton)getObject(id, IButton.class.getName());
    }
    
    @Override
    public IRadioButton getRadioButton(String id){
    	return (IRadioButton)getObject(id, IRadioButton.class.getName());
    }

    @Override
    public ICheckBox getCheckBox(String id) {
        return (ICheckBox)getObject(id, ICheckBox.class.getName());
    }

    @Override
    public IComboBox getComboBox(String id) {
        return (IComboBox)getObject(id, IComboBox.class.getName());
    }

    @Override
    public IDialog getDialog(String id) {
        return (IDialog)getObject(id, IDialog.class.getName());
    }

    @Override
    public IList getList(String id) {
        return (IList)getObject(id, IList.class.getName());
    }

    @Override
    public IMenuBar getMenuBar(String id) {
        return (IMenuBar)getObject(id, IMenuBar.class.getName());
    }

    @Override
    public IOptionPaneDialog getOptionPaneDialog(String id) {
        return (IOptionPaneDialog)getObject(id, IOptionPaneDialog.class.getName());
    }

    @Override
    public IPopupMenu getPopupMenu(String id) {
        return (IPopupMenu)getObject(id, IPopupMenu.class.getName());
    }

    @Override
    public IProgressBar getProgressBar(String id) {
        return (IProgressBar)getObject(id, IProgressBar.class.getName());
    }

    @Override
    public IScrollBar getScrollBar(String id) {
        return (IScrollBar)getObject(id, IScrollBar.class.getName());
    }

    @Override
    public ITabbedPane getTabbedPane(String id) {
        return (ITabbedPane)getObject(id, ITabbedPane.class.getName());
    }

    @Override
    public ITable getTable(String id) {
        return (ITable)getObject(id, ITable.class.getName());
    }

    @Override
    public ITextArea getTextArea(String id) {
        return (ITextArea)getObject(id, ITextArea.class.getName());
    }

    @Override
    public ITextField getTextField(String id) {
        return (ITextField)getObject(id, ITextField.class.getName());
    }

    @Override
    public ITree getTree(String id) {
        return (ITree)getObject(id, ITree.class.getName());
    }
    
    @Override
	public ITreeTable getTreeTable(String id) {
		return (ITreeTable)getObject(id, ITreeTable.class.getName());
	}
    
    @Override
	public IFileSaveDialog saveFileDialog(String windowTitle) {
		throw new RuntimeException("Not Implemented!");
	}

	@Override
	public IFileOpenDialog openFileDialog(String windowTitle) {
		throw new RuntimeException("Not Implemented!");
	}

	@Override
	public IOptionPaneDialog sysOption(String title, String msg) {
		throw new RuntimeException("Not Implemented!");
	}
	
	@Override
	public IDialog sysDialog(String title){
		throw new RuntimeException("Not Implemented!");
	}
	
	@Override
	public IBrowser getBrowser(){
		throw new RuntimeException("Not Implemented!");
	}
	
	@Override
	public ITestObj getTestObj(){
		throw new RuntimeException("Not Implemented!");
	}
	
    public abstract WidgetMap<T> getWidgetMap();
    public abstract String getInterfaceClass(String interfaces);
    
    private WidgetMap<T> getWidgetMap0(){
        try {
            return getWidgetMap();
        } catch (RuntimeException e) {
        	LogManager.getInstance().logError(e);
            return null;
        }
    }
    
    private Object getObject(String id,String interfaces){
        WidgetMap<T> map = getWidgetMap0();
        AbstractWidget<T> wo = null;
		if (id == null) {
			wo =  null;
		} else if (map != null) {
			wo = map.getWidget(id);
		}
        String clazz = getInterfaceClass(interfaces);
        
        return create(clazz, wo);
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static Object create(String clazz,AbstractWidget wo){
        try {
            Class c = wo.getClass().getClassLoader().loadClass(clazz);
            IWidget pw = wo.getParent();
			IObjectFinder finder = pw != null ? pw.getFinder() : wo.getFinder();
            if(pw != null && finder != null){
            	Constructor cc = c.getConstructor(IWidget.class,IFindRule[].class);
                Object rlt = cc.newInstance(pw,wo.getFindRule());
                return rlt;
            }else if(finder != null && wo.getFindRule() != null){
            	Constructor cc = c.getConstructor(IObjectFinder.class,IFindRule[].class);
                Object rlt = cc.newInstance(finder,wo.getFindRule());
                return rlt;
            }else{
            	Constructor cc = c.getConstructor(IWidget.class,IFindRule[].class);
                Object rlt = cc.newInstance(wo,(IFindRule[])null);
                return rlt;
            }
        } catch (ClassNotFoundException e) {
            LogManager.getInstance().logError(e);
        } catch (SecurityException e) {
        	LogManager.getInstance().logError(e);
        } catch (NoSuchMethodException e) {
        	LogManager.getInstance().logError(e);
        } catch (IllegalArgumentException e) {
        	LogManager.getInstance().logError(e);
        } catch (InstantiationException e) {
        	LogManager.getInstance().logError(e);
        } catch (IllegalAccessException e) {
        	LogManager.getInstance().logError(e);
        } catch (InvocationTargetException e) {
        	LogManager.getInstance().logError(e);
        }
        
        return null;
    }
    
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public Object create(String clazz,IFindRule ... findrule){
       
        try {
            Class c = getClass().getClassLoader().loadClass(clazz);
            Constructor cc = c.getConstructor(IObjectFinder.class,IFindRule[].class);
            Object rlt = cc.newInstance(getFinder(),findrule);
            return rlt;
        } catch (ClassNotFoundException e) {
            LogManager.getInstance().logError(e);
        } catch (SecurityException e) {
        	LogManager.getInstance().logError(e);
        } catch (NoSuchMethodException e) {
        	LogManager.getInstance().logError(e);
        } catch (IllegalArgumentException e) {
        	LogManager.getInstance().logError(e);
        } catch (InstantiationException e) {
        	LogManager.getInstance().logError(e);
        } catch (IllegalAccessException e) {
        	LogManager.getInstance().logError(e);
        } catch (InvocationTargetException e) {
        	LogManager.getInstance().logError(e);
        }
        
        return null;
    }

}
