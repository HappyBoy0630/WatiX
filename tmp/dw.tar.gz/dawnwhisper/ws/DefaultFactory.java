package dawnwhisper.ws;

import java.util.HashMap;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;

import dawnwhisper.finder.IFindRule;
import dawnwhisper.finder.IObjectFinder;
import dawnwhisper.widget.TWidget;
import dawnwhisper.widget.interfaces.IButton;
import fonddream.util.ios.JdomHelper;
import fonddream.util.log.LogManager;


public class DefaultFactory<T> extends AbstractFactory<T>{

	private WidgetMap<T> wmap = null;
	private IObjectFinder<T> finder = null;
	private HashMap<String,String> infMap = new HashMap<String,String>();
	
	public DefaultFactory(IObjectFinder<T> finder,String mapFile){
		wmap = new WidgetMap<T>(finder, mapFile);
		this.finder = finder;
	}
	
	@Override
	public IButton[] find(IFindRule... findRules) {
		if(finder == null){
			return null;
		}
		try {
			List<T> ol = finder.findList(findRules);
			IButton rlt[] = new IButton[ol.size()];
			int tag = 0;
			for(T t : ol){
				IButton b = (IButton)create(getInterfaceClass(IButton.class.getName()), new TWidget<T>(finder, t));
				rlt[tag++] = b;
			}
			return rlt;
		} catch (Throwable e) {
			LogManager.getInstance().logError(e);
		}
		
		return null;
	}
	
	@Override
	public IObjectFinder<T> getFinder() {
		return finder;
	}
	
	@Override
	public WidgetMap<T> getWidgetMap() {
		return wmap;
	}

	@Override
	public void refresh() {
		getWidgetMap().refreshMap();
	}
	
	@Override
	public String getInterfaceClass(String interfaces) {
		return infMap.get(interfaces);
	}

	public void updateInterfaceMap(String infName,String implName){
		if(infMap.containsKey(infName))
			infMap.remove(infName);
		infMap.put(infName, implName);
	}
	
	public void updateInterfaceMap(String file){
		updateInterfaceMap(JdomHelper.read(file));
	}
	
	/**
	 * Document format:
	 * <root>
	 *     <IButton>dws.rft.JButton</IButton>
	 *     <ITextField>dws.rft.JTextField</ITextField>
	 * </root>
	 * 
	 * @param infDoc
	 */
	@SuppressWarnings("unchecked")
	public void updateInterfaceMap(Document infDoc){
		if(infDoc == null) return ;
		
		try {
			List<Element> el = (List<Element>)infDoc.getRootElement().getChildren();
			for(Element infe : el){
				updateInterfaceMap(infe.getName(), infe.getTextTrim());
			}
		} catch (Exception e) {
			LogManager.getInstance().logError("DefaultFactory updateInterfaceMap failed.[" + e.getMessage() + "]");
		}
		
	}
	
}
