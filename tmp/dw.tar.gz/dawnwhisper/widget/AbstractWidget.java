package dawnwhisper.widget;

import dawnwhisper.finder.IFindRule;
import dawnwhisper.finder.IObjectFinder;
import dawnwhisper.waitfor.api.ICheck;
import dawnwhisper.waitfor.impl.NOT;
import dawnwhisper.waitfor.impl.WaitFor;
import dawnwhisper.widget.interfaces.IWidget;
import fonddream.util.log.LogManager;

public class AbstractWidget<T> implements IWidget<T>{
    
	protected T mappedObject = null;
    protected IWidget<T> parent = null;
    protected IFindRule[] findRule = null;
    protected IObjectFinder<T> finder = null;
    private String frpath = null;
    
    public AbstractWidget(IWidget<T> parent,IFindRule ... findRule){
        this.parent = parent;
        if(parent != null)
        	finder = parent.getFinder();
        this.findRule = findRule;
    }
    
    public AbstractWidget(IObjectFinder<T> finder,IFindRule ... findRule){
        this.findRule = findRule;
        this.finder = finder;
    }
    
    @Override
    public T getObject() throws Throwable{
    	if(mappedObject != null) return mappedObject;
    	
        FC<T> fc = new FC<T>(this);
        WaitFor.waitFor(fc);
        return fc.finded;
    }

    @Override
    public boolean isExist() throws Throwable{
        return (get() != null);
    }

    @Override
    public void waitForExist() throws Throwable{
    	mappedObject = null;
        FC<T> fc = new FC<T>(this);
        WaitFor.waitFor(fc);
        mappedObject = fc.finded;
    }

    @Override
    public void waitForUnExist() throws Throwable{
    	mappedObject = null;
        WaitFor.waitFor(new NOT(new FC<T>(this)));
    }
    
    @Override
    public T get() throws Throwable{
        T _root = null;
        if(parent != null){
            _root = parent.get();
            if(_root == null) return null;
        }
        if(findRule == null){
        	return _root;
        }
        return finder.find(_root, findRule);
    }
    
    @Override
    public IObjectFinder<T> getFinder() {
        return finder;
    }

    @Override
    public IFindRule[] getFindRule() {
        return findRule;
    }

    @Override
    public IWidget<T> getParent() {
        return parent;
    }
    
    public String toString(){
        IFindRule findRule[] = getFindRule();
        if(findRule == null){
            return "Widget[MappedObject]";
        }
        return "Widget" + fpath();
    }
    
    @Override
	public boolean check() throws Throwable {
		return isExist();
	}
    
    private final String fpath(){
    	if(frpath != null) return frpath;
    	return frpath = fpath(getFindRule());
    }
    
    private static final String fpath(IFindRule ... findRules){
    	if(null != findRules){
    		StringBuilder buf = new StringBuilder("[");
    		for(IFindRule fr : findRules){
    			buf.append(fr.toString()).append("->");
    		}
    		buf.deleteCharAt(buf.length() - 1);
    		buf.deleteCharAt(buf.length() - 1);
    		buf.append("]");
    		
    		return buf.toString();
    	}else{
    		return "[null]";
    	}
    }
    
    private static class FC<T> implements ICheck {
        
        T finded = null;
        AbstractWidget<T> w = null;
        FC(AbstractWidget<T> w){
            this.w = w;
        }
        
        @Override
        public boolean check() throws Throwable {
            long start = System.currentTimeMillis();
            finded = w.get();
            long exp = System.currentTimeMillis() - start;
            if(finded == null){
                LogManager.getInstance().logDebug("Not find " + w.getClass() + w.fpath() + " takes " + exp/1000. + " s.");
            }else{
                LogManager.getInstance().logDebug("Find " + w.getClass() + w.fpath() + " takes " + exp/1000. + " s.");
            }
            return finded != null;
        }
       
    }
    
    
}
