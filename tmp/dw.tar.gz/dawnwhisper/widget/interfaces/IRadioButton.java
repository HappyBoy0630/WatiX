package dawnwhisper.widget.interfaces;

/**
 * 单选按钮
 * 
 * @author zhou
 *
 */
public interface IRadioButton extends IStateButton{
}
