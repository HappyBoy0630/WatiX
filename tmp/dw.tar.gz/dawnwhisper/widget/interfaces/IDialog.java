package dawnwhisper.widget.interfaces;

import dawnwhisper.finder.XProperty;

/**
 * 对话框
 * 
 * @author zhou
 *
 */
public interface IDialog extends IGuiWidget{
	
    /**
     * 关闭对话框
     * @throws Throwable
     */
    void close() throws Throwable;
    
    /**
     * 点击对话框上的某一个按钮
     * @param label      按钮标签名
     * @throws Throwable
     */
    void clickLabel(String label) throws Throwable;
    
    /**
     * 点击通过properties定位的按钮
     * @param properties  查找属性
     * @throws Throwable
     */
    void click(XProperty ... properties) throws Throwable;
    
    /**
     * 通过属性名和属性值定位按钮并点击
     * @param name        查找属性名
     * @param value       查找属性值
     * @throws Throwable
     */
    void click(String name,String value) throws Throwable;
    
    /**
     * 通过属性列表查找输入框并输入
     * @param input        输入值
     * @param properties   查找属性列表
     * @throws Throwable
     */
    void input(String input,XProperty ... properties) throws Throwable;
    
    /**
     * 通过某一属性查找并输入
     * @param input         输入值
     * @param name          查找属性名
     * @param value         查找属性值
     * @throws Throwable
     */
    void input(String input,String name,String value) throws Throwable;
}
