package dawnwhisper.widget.interfaces;

/**
 * 滚动条
 * 
 * @author zhou
 *
 */
public interface IScrollBar extends IGuiWidget{
    
    /**
     * 滚动条滚动到to位置
     * @param to  位置坐标
     * @throws Throwable
     */
    void scrollTo(int to) throws Throwable;
    
    /**
     * 返回滚动条的当前位置
     * @return int
     * @throws Throwable
     */
    int value() throws Throwable;
    
    /**
     * 返回滚动条的最大值
     * @return int
     * @throws Throwable
     */
    int maxValue() throws Throwable;
}
