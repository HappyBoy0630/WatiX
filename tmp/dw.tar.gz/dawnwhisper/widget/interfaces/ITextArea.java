package dawnwhisper.widget.interfaces;


/**
 * 文本域
 * 
 * @author zhou
 *
 */
public interface ITextArea extends ITextField{
    
}
