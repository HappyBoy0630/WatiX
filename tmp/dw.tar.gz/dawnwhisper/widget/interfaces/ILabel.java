package dawnwhisper.widget.interfaces;

import dawnwhisper.waitfor.api.ICheck;

/**
 * 标签
 * 
 * @author zhou
 *
 */
public interface ILabel extends IGuiWidget {
	/**
	 * 获取标签的文字
	 * @return String
	 * @throws Throwable
	 */
	public abstract String getText() throws Throwable;
	
	/**
	 * 获取内容包含判断ICheck
	 * @param text      比较值
	 * @return  ICheck
	 */
	public abstract ICheck textContains(String text);
	
	/**
	 * 获取内容匹配判断ICheck
	 * @param regx      匹配模式串
	 * @return  ICheck
	 */
	public abstract ICheck textMatchs(String regx);
}
