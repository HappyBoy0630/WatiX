package dawnwhisper.widget.interfaces;

import dawnwhisper.waitfor.api.ICheck;


/**
 * 进度条
 * 
 * @author zhou
 *
 */
public interface IProgressBar extends IGuiWidget{
    
	/**
	 * 获取进度条进度
	 * @return  int
	 * @throws Throwable
	 */
	int getValue() throws Throwable;
	
    /**
     * 等待进度条完成
     * 
     * @throws Throwable
     */
    void waitForEnds() throws Throwable;
    
    /**
     * 获取进度条进度完成状态ICheck
     * @return  ICheck
     */
    ICheck endChecker();
}
