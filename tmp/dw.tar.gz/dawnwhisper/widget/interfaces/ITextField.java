package dawnwhisper.widget.interfaces;

import dawnwhisper.waitfor.api.ICheck;

/**
 * 文本框
 * @author zhou
 *
 */
public interface ITextField extends IGuiWidget{
	
    /**
     * 获取文本框的值
     * @return String
     * @throws Throwable
     */
    String getText() throws Throwable;
    
    /**
     * 设置文本框的值
     * @param text  文本框的值
     * @throws Throwable
     */
    void setText(String text) throws Throwable;
    
    /**
     * 比较文本框的值是否包含text
     * @param text   比较内容
     * @throws Throwable
     */
    boolean valueContains(String text) throws Throwable;
    
    /**
     * 等待文本框的值直到包含texts列表中的一项，或超时
     * 参数说明：tcounts是正常值个数，出现异常值则抛出异常
     * @param tcounts   正常值个数，大于texts的个数时全部为正常值
     * @param texts     预期值列表
     * @throws Throwable
     */
    void checkContains(int tcounts,String ... texts) throws Throwable;
    
    /**
     * 获取输入框内容ICheck
     * @param text      比较值
     * @return    ICheck
     */
    ICheck containsChecker(String text);
    
    /**
     * 获取输入框内容ICheck
     * @param regx      匹配模式串
     * @return    ICheck
     */
    ICheck matchChecker(String regx);
}
