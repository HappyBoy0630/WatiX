package dawnwhisper.widget.interfaces;

import dawnwhisper.waitfor.api.ICheck;

public interface IWaitable extends ICheck{
	
	/**
     * 判断对象是否存在
     * @return true or false
     * @throws Throwable
     */
    boolean isExist() throws Throwable;
    
    /**
     * 等待对象出现，或超时抛出异常
     * @throws Throwable
     */
    void waitForExist() throws Throwable;
    
    /**
     * 等待对象消失，或超时抛出异常
     * @throws Throwable
     */
    void waitForUnExist() throws Throwable;
	
}
