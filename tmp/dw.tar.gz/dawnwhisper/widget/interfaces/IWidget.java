package dawnwhisper.widget.interfaces;

import dawnwhisper.finder.IFindRule;
import dawnwhisper.finder.IObjectFinder;

/**
 * 控件基类接口
 * 
 * @author zhou
 *
 */
public interface IWidget<T> extends IWaitable{
	
	/**
	 * 控件测试对象查找方法
	 * 
	 * 该方法为立即返回方法，子类需要自行进行查找时，覆盖此方法。
	 * 
	 * @return  Object or NULL
	 * @throws Throwable
	 */
	T get() throws Throwable;
	
    /**
     * 控件测试对象查找方法
     * 该方法将等待直到查找到非NULL对象值时返回，或超时抛出异常
     * 
     * @return Object
     * @throws Throwable
     */
    T getObject() throws Throwable;
    
    /**
     * 返回对象的查找规则
     * @return  IFindRule
     */
    IFindRule[] getFindRule();
    
    /**
     * 返回对象的查找工具对象实例
     * @return IObjectFinder
     */
    IObjectFinder<T> getFinder();
    
    /**
     * 返回对象的父级对象
     * @return  IWidget
     */
    IWidget<T> getParent();
}
