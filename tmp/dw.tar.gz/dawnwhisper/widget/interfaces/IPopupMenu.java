package dawnwhisper.widget.interfaces;

import dawnwhisper.waitfor.api.ICheck;

/**
 * 弹出菜单
 * 
 * @author zhou
 *
 */
public interface IPopupMenu extends IGuiWidget{
    
    /**
     * 点击/选中弹出菜单
     * check不为null时进行动作完成检查，如果检查不成功则重新执行动作，以此循环直到
     * 动作成功或超时
     * @param path 弹出菜单项路径
     * @throws Throwable
     */
    void select(String path,ICheck check) throws Throwable;
    
    /**
     * 判断是否存在某菜单项
     * @param path   菜单项
     * @return   boolean
     * @throws Throwable
     */
    boolean hasPath(String path) throws Throwable;
    
    /**
     * 判断某菜单项是否被选中
     * @param path   菜单项
     * @return   boolean
     * @throws Throwable
     */
    boolean selected(String path) throws Throwable;
}
