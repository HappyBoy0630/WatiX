package dawnwhisper.widget.interfaces;

public interface IStateButton extends IGuiWidget{
	
    /**
     * 设置按钮状态为选中
     * @throws Throwable
     */
    void select() throws Throwable;
    
    /**
     * 取消按钮的选中状态
     * @throws Throwable
     */
    void unselect() throws Throwable;
    
    /**
     * 返回带状态的按钮的选中状态
     * @return true or false
     * @throws Throwable
     */
    boolean selected() throws Throwable;
}
