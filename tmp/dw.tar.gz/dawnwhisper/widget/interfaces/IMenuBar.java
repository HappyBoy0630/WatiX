package dawnwhisper.widget.interfaces;

import dawnwhisper.waitfor.api.ICheck;

/**
 * 菜单栏
 * 
 * @author zhou
 *
 */
public interface IMenuBar extends IGuiWidget{
	
    /**
     * 点击菜单栏路径
     * check不为null时进行动作完成检查，如果检查不成功则重新执行动作，以此循环直到
     * 动作成功或超时
     * @param menuPath 菜单路径
     * @throws Throwable
     */
    void select(String menuPath,ICheck check) throws Throwable;
}
