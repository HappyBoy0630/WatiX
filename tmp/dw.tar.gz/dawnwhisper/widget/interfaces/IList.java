package dawnwhisper.widget.interfaces;

import dawnwhisper.waitfor.api.ICheck;

/**
 * 列表
 * 
 * @author zhou
 *
 */
public interface IList extends IGuiWidget{
    
    /**
     * 点击一列表项
     * check不为null时进行动作完成检查，如果检查不成功则重新执行动作，以此循环直到
     * 动作成功或超时
     * @param listItem
     * @param check
     * @throws Throwable
     */
    void click(String listItem,ICheck check) throws Throwable;
    
    /**
     * 双击一列表项
     * check不为null时进行动作完成检查，如果检查不成功则重新执行动作，以此循环直到
     * 动作成功或超时
     * @param listItem
     * @param check
     * @throws Throwable
     */
    void doubleClick(String listItem,ICheck check) throws Throwable;
    
    /**
     * 右键点击列表项
     * check不为null时进行动作完成检查，如果检查不成功则重新执行动作，以此循环直到
     * 动作成功或超时
     * @param listItem
     * @param check
     * @throws Throwable
     */
    void rightClick(String listItem,ICheck check) throws Throwable;
    
    /**
     * 按住CTRL键左键点击列表项
     * check不为null时进行动作完成检查，如果检查不成功则重新执行动作，以此循环直到
     * 动作成功或超时
     * @param listItem
     * @param check
     * @throws Throwable
     */
    void ctrlClick(String listItem,ICheck check) throws Throwable;
    
    /**
     * 按住SHIFT键左键点击列表项
     * check不为null时进行动作完成检查，如果检查不成功则重新执行动作，以此循环直到
     * 动作成功或超时
     * @param listItem
     * @param check
     * @throws Throwable
     */
    void shiftClick(String listItem,ICheck check) throws Throwable;
    

    /**
     * 检查列表是否包含列表项集合
     * @param listItem  列表项集合
     * @return true（全部包含）,false
     * @throws Throwable
     */
    boolean contains(String ... listItem) throws Throwable;
    
    /**
     * 获取列表的所有项
     * @return
     * @throws Throwable
     */
    String[] getItems() throws Throwable;
}
