package dawnwhisper.widget.interfaces;

import dawnwhisper.waitfor.api.IAction;
import dawnwhisper.waitfor.api.ICheckAction;

public interface IOptionPaneDialog extends IDialog{

    /**
     * 获取错误对话框（包含error信息）检查接口ICheckAction
     * （检查通过执行action的动作）
     * 
     * @param error     弹出框信息（或部分信息）
     * @param action    执行动作接口
     * @return ICheckAction
     */
    ICheckAction getStateErrorChecker(String error,IAction action);
    
    /**
     * 获取非错误对话框（包含info信息）检查接口ICheckAction
     * （检查通过执行action的动作）
     * @param info        弹出框信息（或部分信息）
     * @param btnLabel    按钮标签
     * @param action      动作接口
     * @return  ICheckAction
     */
    ICheckAction getStateChecker(String info,String btnLabel,IAction action);
    
    /**
     * 获取提示框信息
     * @return String
     */
    String getInfo();
    
    /**
     * 获取提示框标题
     * @return String
     */
    String getTitle();
}
