package dawnwhisper.widget.interfaces;


/**
 * 打开文件对话框接口
 * 
 * @author zhou
 *
 */
public interface IFileOpenDialog extends IWaitable{
	
	/**
	 * 打开文件
	 * @param fileName    文件名
	 * @throws Throwable
	 */
	public void open(String fileName) throws Throwable;
	
	/**
	 * 取消打开文件操作，关闭文件对话框
	 * @throws Throwable
	 */
	public void cancel() throws Throwable;
}
