package dawnwhisper.widget.interfaces;

import dawnwhisper.waitfor.api.ICheck;


/**
 * 下拉框操作接口
 * 
 * @author zhou
 *
 */
public interface IComboBox extends IGuiWidget{
    
    /**
     * 选中下拉框text项
     * @param text  下拉框的某一项的值
     * @throws Throwable
     */
    void select(String text) throws Throwable;
    
    /**
     * 检查下拉框是否包含相应的值
     * @param text   下拉项列表
     * @return true（全部包含） or false（不包含某一项或多项）
     * @throws Throwable
     */
    boolean contains(String ... text) throws Throwable;
    
    /**
     * 获取下拉框当前值
     * @return
     * @throws Throwable
     */
    String getValue() throws Throwable;
    
    /**
     * 获取下拉框的所有项
     * @return String[]
     * @throws Throwable
     */
    String[] getItems() throws Throwable;
    
    /**
     * 获取判断是否存在某些项的ICheck
     * @param exist   预期是否存在（true/false）
     * @param text    预期列表项
     * @return  ICheck
     */
    ICheck itemChecker(boolean exist, String ... text);
}
