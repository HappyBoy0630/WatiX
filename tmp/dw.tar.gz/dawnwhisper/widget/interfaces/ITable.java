package dawnwhisper.widget.interfaces;

import java.util.List;

import dawnwhisper.finder.IFindRule;
import dawnwhisper.waitfor.api.ICheck;

/**
 * 表格
 * 
 * @author zhou
 *
 */
public interface ITable extends IGuiWidget{
    
    /**
     * 点击Table的row行column列
     * check不为null时进行动作完成检查，如果检查不成功则重新执行动作，以此循环直到
     * 动作成功或超时
     * 如果带CheckBox，则选中CheckBox
     * @param row        行
     * @param column     列
     * @param check      动作检查接口
     * @throws Throwable
     */
    void click(int row,int column, ICheck check) throws Throwable;
    
    /**
     * 右键点击Table的row行column列
     * check不为null时进行动作完成检查，如果检查不成功则重新执行动作，以此循环直到
     * 动作成功或超时
     * @param row        行
     * @param column     列
     * @param check      动作检查接口
     * @throws Throwable
     */
    void rightClick(int row,int column, ICheck check) throws Throwable;
    
    /**
     * 双击Table的row行column列
     * check不为null时进行动作完成检查，如果检查不成功则重新执行动作，以此循环直到
     * 动作成功或超时
     * @param row        行
     * @param column     列
     * @param check      动作检查接口
     * @throws Throwable
     */
    void doubleClick(int row,int column, ICheck check) throws Throwable;
    
    /**
     * 点击列头
     * @param columnName    列名
     */
    void clickColumnHeader(String columnName);
    
    /**
     * 返回row行是否被选中
     * @param row   行
     * @return true（选中）
     * @throws Throwable
     */
    boolean isSelected(int row) throws Throwable;
    
    /**
     * 返回Table行数
     * @return int
     * @throws Throwable
     */
    int getRowCount() throws Throwable;
    
    /**
     * 返回table列数
     * @return int
     * @throws Throwable
     */
    int getColumnCount() throws Throwable;
    
    /**
     * 返回列名为columnName的列的值为columnValue的行号
     * -1表示不存在
     * @param columnName     列名
     * @param columnValue    列值
     * @return  int 
     * @throws Throwable
     */
    int getRowIndex(String columnName,String columnValue) throws Throwable;
    
    /**
     * 返回列名为columnName的列的列号，-1表示列不存在
     * @param columnName      列名
     * @return int
     * @throws Throwable
     */
    int getColumnIndex(String columnName) throws Throwable;
    
    /**
     * 获取表的(row,col)表示的单元格的值，单元格不存在时返回null
     * @param row   行号
     * @param col   列号
     * @return  String
     * @throws Throwable
     */
    String getCellData(int row,int col) throws Throwable;
    
    /**
     * 返回行号为row的行的所有单元格的值，行不存在时返回null
     * @param row   行号
     * @return List<String>
     * @throws Throwable
     */
    List<String> getRowData(int row) throws Throwable;
    
    /**
     * 返回表格的所有值
     * @return List<String[]>
     * @throws Throwable
     */
    List<String[]> getTableData() throws Throwable;
    
    /**
     * 检查列名为columnName的列的值为columnValue的行的col列的值，直到出现status列表中
     * 的某一项时退出检查，或超时退出。
     * 如果出现正常值，方法正常退出；出现异常值，方法抛出异常。
     * 
     * 参数tcounts说明：tcounts表示status列表中正常值的个数（从第一个起）。
     * 
     * @param columnName        列号
     * @param columnValue       列值
     * @param col               检查的列号
     * @param timeout           超时时间，-1时采用系统默认超时时间
     * @param tcounts           正常值个数
     * @param status            状态值列表
     * @throws Throwable
     */
    void checkRowStatus(String columnName,String columnValue,int col,int timeout,int tcounts,String ... status) throws Throwable;
    
    /**
     * 等待列名为columnName的列的值为columnValue的行出现
     * @param columnName     列名
     * @param columnValue    列值
     * @param exists         true 存在,false 不存在
     * @param timeout        超时时间,-1时采用系统默认超时
     * @throws Throwable
     */
    void waitForRow(String columnName,String columnValue,boolean exists,int timeout) throws Throwable;
    
    /**
     * 比较行内容
     * 
     * @param row          行号
     * @param expected     比较对象，格式"columnName:=columnValue,columnName1:=columnValue1,..."
     * @return 完全一致返回true，其他false
     * @throws Throwable
     */
    boolean checkRowContents(int row,String... expected) throws Throwable;
    
    /**
     * 等待Table出现了rows行数据
     * @param rows       行数
     * @param timeout    超时时间，-1时取系统默认超时时间
     * @throws Throwable
     */
    void waitForTable(int rows,int timeout) throws Throwable;
    
    /**
     * 返回table的列名List
     * @return  List<String>
     * @throws Throwable
     */
    List<String> getColumnNames() throws Throwable;
    
    /**
     * 选中所有colName列值为colValue的行
     * @param colName     列名
     * @param colValue    列值
     */
    void selectRows(String colName,String colValue);
    
    /**
     * 查找并返回所有colName列值为colValue的行的数据
     * @param colName     列名
     * @param colValue    列值
     * @return List<String[]>
     */
    List<String[]> getRowData(String colName,String colValue);
    
    /**
     * 获取行ICheck（行存在时返回true）
     * @param columnName     列名
     * @param columnValue    列值
     * @return   ICheck
     */
    ICheck rowChecker(String columnName,String columnValue);
    
    /**
     * 获取行状态ICheck。
     * ICheck说明：
     * 检查列名为columnName的列的值为columnValue的行的col列的值，直到出现status列表中
     * 的某一项时返回true
     * 
     * 
     * @param columnName        列号
     * @param columnValue       列值
     * @param col               检查的列号
     * @param status            状态值列表
     * @return  ICheck
     */
    ICheck rowStatusChecker(String columnName,String columnValue,int col,String ... status);
    
    /**
     * 获取表行数ICheck（行数大于count时返回true）
     * @param conut    预期行数>count
     * @return  ICheck
     */
    ICheck rowCountChecker(int conut);
    
    /**
     * 点击表格内部控件
     * @param row         行
     * @param col         列
     * @param findRule    内部控件查找规则（自动在TD内部查找）
     * @param checker     点击是否生效检查接口
     * @throws Throwable
     */
    void clickContent(int row, int col, IFindRule findRule, ICheck checker) throws Throwable;
    
}
