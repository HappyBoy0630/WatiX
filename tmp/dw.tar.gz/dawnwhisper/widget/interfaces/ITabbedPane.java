package dawnwhisper.widget.interfaces;

/**
 * Tab面板
 * 
 * @author zhou
 *
 */
public interface ITabbedPane extends IGuiWidget{
    
    /**
     * 选择Tab页
     * @param tabTitle
     * @throws Throwable
     */
    void selectTab(String tabTitle) throws Throwable;
    
    /**
     * 检查Tab页是否存在
     * 当tab页存在（exists=true）或不存在（exists=false）时返回True
     * @param title tab页标题
     * @param exists Tab页预期结果
     * @throws Throwable
     */
    void checkTabs(String title,boolean exists) throws Throwable;
    
    /**
     * 返回所有Tab页标题
     * @return String
     * @throws Throwable
     */
    String[] getTabs() throws Throwable;
    
}
