package dawnwhisper.widget.interfaces;

public interface ITreeTable extends ITable{
	
	/**
	 * 展开某一行
	 * @param row      行
	 */
	void expandRow(int row);
	
	/**
	 * 获取某一行的展开状态
	 * @param row      行
	 * @return  boolean
	 */
	boolean isExpanded(int row);
	
	/**
	 * 返回某一行的子表
	 * @param row  行号(从0开始)
	 * @return ITable
	 */
	ITable getSubTable(int row);
	
	/**
	 * 返回某一行(colName列值为colValue的行)的子表
	 * @param colName     列名
	 * @param colValue    列值
	 * @return ITable
	 */
	ITable getSubTable(String colName,String colValue);
	
}
