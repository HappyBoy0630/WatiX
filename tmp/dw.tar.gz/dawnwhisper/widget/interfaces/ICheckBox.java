package dawnwhisper.widget.interfaces;


public interface ICheckBox extends IStateButton{

}
