package dawnwhisper.widget.interfaces;

public interface IToggleButton extends IStateButton{

}
