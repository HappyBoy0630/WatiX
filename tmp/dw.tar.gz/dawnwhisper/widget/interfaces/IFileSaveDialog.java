package dawnwhisper.widget.interfaces;


/**
 * 保存文件对话框接口
 * 
 * @author zhou
 *
 */
public interface IFileSaveDialog extends IWaitable{
	/**
	 * 保存文件
	 * @param fileName  文件名
	 * @throws Throwable
	 */
	public void save(String fileName) throws Throwable;
	
	/**
	 * 取消保存操作，关闭文件对话框
	 * @throws Throwable
	 */
	public void cancel() throws Throwable;
}
