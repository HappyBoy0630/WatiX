package dawnwhisper.widget.interfaces;

import dawnwhisper.waitfor.api.ICheck;

/**
 * 按钮操作接口
 * 
 * @author zhou
 *
 */
public interface IButton extends IGuiWidget{
	
	/**
	 * 获取按钮文字标题
	 * @return String
	 */
	public abstract String getLabel();
	
	/**
	 * 获取标签ICheck（包含label时返回true）
	 * @param label   预期标签
	 * @return   ICheck
	 */
	ICheck labelContains(String label);
}
