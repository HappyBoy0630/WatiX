package dawnwhisper.widget.interfaces;

import java.awt.Point;
import java.awt.Rectangle;

import dawnwhisper.waitfor.api.ICheck;

/**
 * 图形控件接口
 * 
 * @author zhou
 *
 */
public interface IGuiWidget extends IWaitable{
    
    /**
     * 控件是否在屏幕上显示
     * @return true（显示）, false（隐藏）
     * @throws Throwable
     */
    public abstract boolean isShowing() throws Throwable;

    /**
     * 控件是否可点击
     * @return true/false
     * @throws Throwable
     */
    public abstract boolean isEnabled() throws Throwable;

    /**
     * 控件是否可编辑
     * @return
     * @throws Throwable
     */
    public abstract boolean isEditabled() throws Throwable;
    
    /**
     * 控件是否透明
     * @return true/false
     * @throws Throwable
     */
    public abstract boolean isOpaque() throws Throwable;

    /**
     * 控件是否有焦点
     * @return true/false
     * @throws Throwable
     */
    public abstract boolean hasFocus() throws Throwable;

    /**
     * 坐标是否在控件内部
     * @param point  坐标点
     * @return true/false
     * @throws Throwable
     */
    public abstract boolean isPointInObject(Point point) throws Throwable;

    /**
     * 控件在屏幕上的区域
     * @return Rectangle
     * @throws Throwable
     */
    public abstract Rectangle getScreenRectangle() throws Throwable;

    /**
     * 左键点击控件
     * check不为null时进行动作完成检查，如果检查不成功则重新执行动作，以此循环直到
     * 动作成功或超时
     * @param check 动作检查逻辑
     * @throws Throwable
     */
    public abstract void click(ICheck check) throws Throwable;

    /**
     * 右键点击控件
     * check不为null时进行动作完成检查，如果检查不成功则重新执行动作，以此循环直到
     * 动作成功或超时
     * @param check 动作检查逻辑
     * @throws Throwable
     */
    public abstract void rightClick(ICheck check) throws Throwable;

    /**
     * 左键点击控件的某一点，如果坐标点超出控件范围，抛出错误
     * check不为null时进行动作完成检查，如果检查不成功则重新执行动作，以此循环直到
     * 动作成功或超时
     * 
     * @param point  点击坐标
     * @param check  动作检查逻辑
     * @throws Throwable
     */
    public abstract void click(Point point,ICheck check) throws Throwable;

    /**
     * 右键点击控件的某一点，如果坐标点超出控件范围，抛出错误
     * check不为null时进行动作完成检查，如果检查不成功则重新执行动作，以此循环直到
     * 动作成功或超时
     * 
     * @param point  点击坐标
     * @param check  动作检查逻辑
     * @throws Throwable
     */
    public abstract void rightClick(Point point,ICheck check) throws Throwable;

    /**
     * 左键双击控件
     * check不为null时进行动作完成检查，如果检查不成功则重新执行动作，以此循环直到
     * 动作成功或超时
     * 
     * @param check
     * @throws Throwable
     */
    public abstract void doubleClick(ICheck check) throws Throwable;
    
    /**
     * 获取控件的使能检查对象
     * @return  ICheck
     */
    public abstract ICheck enableChecker();
    
    /**
     * 获取控件的编辑状态检查对象
     * @return  ICheck
     */
    public abstract ICheck editableChecker();
}
