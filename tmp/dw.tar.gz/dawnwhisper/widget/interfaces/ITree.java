package dawnwhisper.widget.interfaces;

import java.util.List;

import dawnwhisper.waitfor.api.ICheck;

/**
 * 
 * 树控件操作接口
 * 
 * @author zhou
 *
 */
public interface ITree extends IGuiWidget{
	
	/**
	 * 通过Tree路径选择节点，如果带有CheckBox则选中或去选中。
	 * 如果是去选中没有CheckBox的树，则通过选中根节点来实现。
	 * 
	 * @param treePath     树路径
	 * @param select       选中（True）或去选中（False）
	 * @throws Throwable
	 */
	void selectByPath(String treePath, boolean select) throws Throwable;
	
    /**
     * 右键点击树路径表示的节点
     * 
     * @param treePath     树路径
     * @param check        动作检查接口
     * @throws Throwable
     */
    void rightClick(String treePath,ICheck check) throws Throwable;
    
    /**
     * 双击树路径表示的节点
     * 
     * @param treePath     树路径
     * @param check        动作检查接口
     * @throws Throwable
     */
    void doubleClick(String treePath,ICheck check) throws Throwable;
    
    /**
     * 等待treePath表示的树节点出现或消失
     * 
     * @param treePath     树路径
     * @param exists       出现（True）或消失（False）
     * @throws Throwable
     */
    void checkPath(String treePath,boolean exists) throws Throwable;
    
    /**
     * 检查某树节点是否被选中
     * 
     * @param treePath     树路径
     * @return  true（选中） or false （未选中）
     * @throws Throwable
     */
    boolean selected(String treePath) throws Throwable;
    
    /**
     * 获取树被选中的所有节点的路径列表
     * 
     * @return  List<String>
     * @throws Throwable
     */
    List<String> getSelectedPath() throws Throwable;
    
    /**
     * 获取树所有节点路径列表
     * 
     * @return  List<String>
     * @throws Throwable
     */
    List<String> getAllPath() throws Throwable;
    
    /**
     * 获取树包含节点ICheck
     * @param exists  是否存在
     * @param paths   树节点/路径
     * @return  ICheck
     */
    ICheck containsChecker(boolean exists, String ... paths);
}
