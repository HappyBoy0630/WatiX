package dawnwhisper.widget;

/**
 * 测试程序对象
 * 
 * @author zhou
 *
 */
public interface ITestObj {
	/**
	 * 获取焦点
	 */
	void focus();
    
    /**
     * 最大化被测程序窗口
     */
    void maximize();
    
    /**
     * 最小化被测程序窗口
     */
    void minimize();
    
    /**
     * 关闭被测程序
     */
    void close();
    
    /**
     * 打开被测程序
     * @return  boolean
     */
    boolean open();
    
    /**
     * 获取被测对象是否最大化
     * @return
     */
    boolean maximized();
	
	/**
	 * 获取测试对象是否最小化
	 * @return
	 */
	boolean iconed();
	
	/**
	 * 获取被测对象是否获取焦点
	 * @return
	 */
	boolean focused();
	
	/**
	 * 获取被测对象是否置于最上层
	 * @return
	 */
	boolean isOnTop();
}
