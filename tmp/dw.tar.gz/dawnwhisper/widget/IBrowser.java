package dawnwhisper.widget;

public interface IBrowser extends ITestObj{
	
	/**
	 * 向后页面跳转
	 */
	void back();
	
	/**
	 * 向前页面跳转
	 */
	void forward();
	
	/**
	 * 刷新当前页面
	 */
	void refresh();
	
	/**
	 * 导航到某页面
	 * @param url  页面链接
	 */
	void navigate(String url);
	
}
