package dawnwhisper.widget;


import dawnwhisper.finder.IFindRule;
import dawnwhisper.finder.IObjectFinder;

public final class TWidget<T> extends AbstractWidget<T> {

	private T object = null;
	
	public TWidget(IObjectFinder<T> finder,T to) {
		super(finder, (IFindRule[])null);
		object = to;
	}

	@Override
	public T get() throws Throwable {
		return object;
	}
}
