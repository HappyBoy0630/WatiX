package dawnwhisper.finder;

import java.util.ArrayList;
import java.util.List;

/**
 * 查找接口的默认实现
 * 
 * @author zhou
 *
 */
public class DefaultFindRule implements IFindRule{

    protected List<XProperty> properties = new ArrayList<XProperty>();
    
    public DefaultFindRule(String pName,String pValue){
        this(new XProperty[]{new XProperty(pName,pValue)});
    }
    
    public DefaultFindRule(String pName,String pValue,String pName1,String pValue1){
        this(new XProperty[]{new XProperty(pName,pValue),new XProperty(pName1,pValue1)});
    }
    
    public DefaultFindRule(XProperty ... xps){
        if(xps != null){
            for(XProperty xp : xps) properties.add(xp);
        }
    }

    public DefaultFindRule addProperty(String pn,String pv){
    	if(!has(pn))
    		properties.add(new XProperty(pn,pv));
        return this;
    }
    
    public DefaultFindRule addPattern(String pn,String pv){
    	if(!has(pn))
    		properties.add(new XProperty(pn,pv,XProperty.PATTERN));
        return this;
    }
    
    public DefaultFindRule addPartMatch(String pn,String pv){
    	if(!has(pn))
    		properties.add(new XProperty(pn,pv,XProperty.CONTAINS));
        return this;
    }
    
    @Override
    public XProperty[] gets() {
        return properties.toArray(new XProperty[0]);
    }
    
    @Override
    public final boolean has(String pName){
		XProperty[] xps = gets();
		
		for(XProperty xp : xps){
			if(xp.name != null && xp.name.equals(pName))
				return true;
		}
		
		return false;
	}

    @Override
	public final String get(String pName){
		XProperty[] xps = gets();
		
		for(XProperty xp : xps){
			if(xp.name != null && xp.name.equals(pName))
				return xp.value;
		}
		
		return null;
	}
	
	public IFindRule id(String id) {
		addProperty(ID, id);
		return this;
	}

	public IFindRule tag(String tag) {
		addProperty(TAG, tag);
		return this;
	}

	public IFindRule clazz(String clazz) {
		addProperty(CLASS, clazz);
		return this;
	}

	public IFindRule content(String content) {
		addProperty("content", content, XProperty.CONTAINS);
		return this;
	}
	
	public IFindRule name(String name) {
		addProperty(NAME, name);
		return this;
	}
	
	public IFindRule parent(String pid) {
		addProperty(PARENT, pid);
		return this;
	}

	public IFindRule frame(String frame) {
		addProperty(FRAME, frame);
		return this;
	}

	public IFindRule item(int idx) {
		addProperty(ITEM, String.valueOf(idx));
		return this;
	}

	public IFindRule href(String href) {
		addProperty(HREF, href, XProperty.CONTAINS);
		return this;
	}
	
	public IFindRule xpath(String xpath) {
		addProperty(XPATH, xpath);
		return this;
	}

	public IFindRule with(String propName, String propValue,int matchType) {
		addProperty(propName, propValue,matchType);
		return this;
	}
    
    public String toString(){
        
        StringBuilder sb = new StringBuilder();
        for(XProperty xp : gets()){
            sb.append(xp.name).append("=").append(xp.value).append("(" + xp.matchType + "),");
        }
        
        return  (sb.length() > 2 ? sb.deleteCharAt(sb.length() - 1).toString().trim() : "");
    }

    final void addProperty(String pn,String pv,int matchType){
    	if(!has(pn))
    		properties.add(new XProperty(pn,pv,matchType));
    }

}
