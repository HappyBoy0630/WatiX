package dawnwhisper.finder;

import java.util.List;

public abstract class AbstractFinder<T> implements IObjectFinder<T>{

	private IFindMonitor findMonitor = null;
	private IExecMonitor execMonitor = null;

	@Override
	public void setExecMonitor(IExecMonitor execMonitor) {
		this.execMonitor = execMonitor;
	}

	@Override
	public void setFindMonitor(IFindMonitor monitor) {
		this.findMonitor = monitor;
	}
	
	@Override
	public final T find(IFindRule ... findRules) throws Throwable {
		return find(null, findRules);
	}
	
	@Override
	public final T find(Object root, IFindRule ... findRules) throws Throwable {
		String id = "find" + System.currentTimeMillis();
		before(id);
		T t = findInner(root, findRules);
		after(id);
		return t;
	}

	@Override
	public final List<T> findList(IFindRule ... ifindrules) throws Throwable {
		return findList(null,ifindrules);
	}
	
	@Override
	public final List<T> findList(Object root,IFindRule... ifindrules) throws Throwable {
		String id = "findList" + System.currentTimeMillis();
		before(id);
		List<T> t = findListInner(root,ifindrules);
		after(id);
		return t;
	}
	
	public abstract T findInner(Object root, IFindRule ... findRule) throws Throwable;
	
	public abstract List<T> findListInner(Object root, IFindRule... ifindrules) throws Throwable;
	
	private final void before(String id){
		if (execMonitor != null) {
			while (execMonitor.status() != IExecMonitor.RUN) {
				if (execMonitor.status() == IExecMonitor.SKIP
						|| execMonitor.status() == IExecMonitor.STOP) {
					throw new RuntimeException("TE SKIP|STOP.");
				}
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
				}
			}
		}
		if(findMonitor != null){
			findMonitor.start(id);
		}
	}
	
	private final void after(String id){
		if(findMonitor != null){
			findMonitor.end(id);
		}
	}
}
