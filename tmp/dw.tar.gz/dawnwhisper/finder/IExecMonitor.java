package dawnwhisper.finder;

public interface IExecMonitor {
	int RUN = 0;
	int PAUSE = 1;
	int STOP = 2;
	int SKIP = 3;
	
	public int status();
}
