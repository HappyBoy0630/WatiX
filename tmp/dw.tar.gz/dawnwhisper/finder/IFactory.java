package dawnwhisper.finder;

import dawnwhisper.widget.IBrowser;
import dawnwhisper.widget.ITestObj;
import dawnwhisper.widget.interfaces.IButton;
import dawnwhisper.widget.interfaces.ICheckBox;
import dawnwhisper.widget.interfaces.IComboBox;
import dawnwhisper.widget.interfaces.IDialog;
import dawnwhisper.widget.interfaces.IFileOpenDialog;
import dawnwhisper.widget.interfaces.IFileSaveDialog;
import dawnwhisper.widget.interfaces.ILabel;
import dawnwhisper.widget.interfaces.IList;
import dawnwhisper.widget.interfaces.IMenuBar;
import dawnwhisper.widget.interfaces.IOptionPaneDialog;
import dawnwhisper.widget.interfaces.IPopupMenu;
import dawnwhisper.widget.interfaces.IProgressBar;
import dawnwhisper.widget.interfaces.IRadioButton;
import dawnwhisper.widget.interfaces.IScrollBar;
import dawnwhisper.widget.interfaces.ITabbedPane;
import dawnwhisper.widget.interfaces.ITable;
import dawnwhisper.widget.interfaces.ITextArea;
import dawnwhisper.widget.interfaces.ITextField;
import dawnwhisper.widget.interfaces.IToggleButton;
import dawnwhisper.widget.interfaces.ITree;
import dawnwhisper.widget.interfaces.ITreeTable;

/**
 * 控件统一生成/获取接口
 * 
 * @author zhou
 *
 */
public interface IFactory {
	
	/**
	 * 刷新Factory,适用于使用Map配置文件方式，该方法用于清空缓存
	 */
	void refresh();
	
	/**
	 * 获取该对象工厂引用的对象查找器（也是被测对象的引用指针）
	 * @return IObjectFinder<?>
	 */
	IObjectFinder<?> getFinder();
	
    /**
     * 从配置文件获取IButton实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return IButton
     */
    IButton getButton(String id);
    
    /**
     * 从配置文件获取ITextField实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return ITextField
     */
    ITextField getTextField(String id);
    
    /**
     * 从配置文件获取ITextArea实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return ITextArea
     */
    ITextArea getTextArea(String id);
    
    /**
     * 从配置文件获取ICheckBox实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return ICheckBox
     */
    ICheckBox getCheckBox(String id);
    
    /**
     * 从配置文件获取IComboBox实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return IComboBox
     */
    IComboBox getComboBox(String id);
    
    /**
     * 从配置文件获取IDialog实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return IDialog
     */
    IDialog getDialog(String id);
    
    /**
     * 从配置文件获取IList实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return IList
     */
    IList getList(String id);
    
    /**
     * 从配置文件获取IMenuBar实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return IMenuBar
     */
    IMenuBar getMenuBar(String id);
    
    /**
     * 从配置文件获取IPopupMenu实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return IPopupMenu
     */
    IPopupMenu getPopupMenu(String id);
    
    /**
     * 从配置文件获取IProgressBar实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return IProgressBar
     */
    IProgressBar getProgressBar(String id);
    
    /**
     * 从配置文件获取IScrollBar实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return IScrollBar
     */
    IScrollBar getScrollBar(String id);
    
    /**
     * 从配置文件获取ITabbedPane实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return ITabbedPane
     */
    ITabbedPane getTabbedPane(String id);
    
    /**
     * 从配置文件获取ITable实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return ITable
     */
    ITable getTable(String id);
    
    /**
     * 从配置文件获取ITree实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return ITree
     */
    ITree getTree(String id);
    
    /**
     * 从配置文件获取ITreeTable实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return ITreeTable
     */
    ITreeTable getTreeTable(String id);
    
    /**
     * 从配置文件获取IOptionPaneDialog实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return IOptionPaneDialog
     */
    IOptionPaneDialog getOptionPaneDialog(String id);
    
    /**
     * 从配置文件获取IToggleButton实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return IToggleButton
     */
    IToggleButton getToggleButton(String id);
    
    /**
     * 从配置文件获取IRadioButton实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return IRadioButton
     */
    IRadioButton getRadioButton(String id);
    
    /**
     * 从配置文件获取ILabel实例，ID为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param id  配置文件中的控件ID
     * @return ILabel
     */
    ILabel getLabel(String id);
    
    /**
     * 生成IButton控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return IButton
     */
    IButton button(IFindRule ... findRule);
    
    /**
     * 生成ITextField控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return ITextField
     */
    ITextField textField(IFindRule ... findRule);
    
    /**
     * 生成ITextArea控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return ITextArea
     */
    ITextArea textArea(IFindRule ... findRule);
    
    /**
     * 生成ICheckBox控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return ICheckBox
     */
    ICheckBox checkBox(IFindRule ... findRule);
    
    /**
     * 生成IComboBox控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return IComboBox
     */
    IComboBox comboBox(IFindRule ... findRule);
    
    /**
     * 生成IDialog控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return IDialog
     */
    IDialog dialog(IFindRule ... findRule);
    
    /**
     * 生成IList控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return IList
     */
    IList list(IFindRule ... findRule);
    
    /**
     * 生成IMenuBar控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return IMenuBar
     */
    IMenuBar menuBar(IFindRule ... findRule);
    
    /**
     * 生成IPopupMenu控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return IPopupMenu
     */
    IPopupMenu popupMenu(IFindRule ... findRule);
    
    /**
     * 生成IProgressBar控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return IProgressBar
     */
    IProgressBar progressBar(IFindRule ... findRule);
    
    /**
     * 生成IScrollBar控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return IScrollBar
     */
    IScrollBar scrollBar(IFindRule ... findRule);
    
    /**
     * 生成ITabbedPane控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return ITabbedPane
     */
    ITabbedPane tabbedPane(IFindRule ... findRule);
    
    /**
     * 生成ITable控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return ITable
     */
    ITable table(IFindRule ... findRule);
    
    /**
     * 生成ITree控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return ITree
     */
    ITree tree(IFindRule ... findRule);
    
    /**
     * 生成ITreeTable控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return ITreeTable
     */
    ITreeTable treeTable(IFindRule ... findRule);
    
    /**
     * 生成IOptionPaneDialog控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return IOptionPaneDialog
     */
    IOptionPaneDialog optionPaneDialog(IFindRule ... findRule);
    
    /**
     * 生成IToggleButton控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return IToggleButton
     */
    IToggleButton toggleButton(IFindRule ... findRule);
    
    /**
     * 生成IRadioButton控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return IRadioButton
     */
    IRadioButton radioButton(IFindRule ... findRule);
    
    /**
     * 生成ILabel控件实例，findRule为null时意味着该控件为系统单例（定位条件系统内唯一）
     * @param findRule  控件查找规则
     * @return ILabel
     */
    ILabel label(IFindRule ... findRule);
    
    /**
     * 直接查找出系统中符合规则findRules的对象，包装为IButton接口
     * @param findRules  查找对象的规则序列，分层查找
     * @return IButton[]
     */
    IButton[] find(IFindRule ... findRules);
    
    /**
     * 获取系统保存文件对话框操作接口
     * @param windowTitle    对话框标题
     * @return   IFileSaveDialog
     */
    IFileSaveDialog saveFileDialog(String windowTitle);
    
    /**
     * 获取系统打开文件对话框操作接口
     * @param windowTitle    对话框标题
     * @return   IFileOpenDialog
     */
    IFileOpenDialog openFileDialog(String windowTitle);
    
    /**
     * 获取系统提示对话框
     * @param title    提示对话框标题
     * @param msg      对话框内容（部分或全部）
     * @return   IOptionPaneDialog
     */
    IOptionPaneDialog sysOption(String title,String msg);
    
    /**
     * 获取系统操作对话框
     * @param title    提示对话框标题
     * @param msg      对话框内容（部分或全部）
     * @return   IOptionPaneDialog
     */
    IDialog sysDialog(String title);
    
    /**
     * 获取关联的浏览器
     * @return  IBrowser
     */
    IBrowser getBrowser();
    
    /**
     * 获取关联的测试对象
     * @return  IBrowser
     */
    ITestObj getTestObj();
}
