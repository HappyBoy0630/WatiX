package dawnwhisper.finder;

/**
 * 避免在查找过程中吊死，通过此接口进行监控
 * 
 * @author zhou
 *
 */
public interface IFindMonitor {
	
	/**
	 * 注册一次查找开始
	 * @param id    此次查找序列号
	 */
	public abstract void start(String id);
	
	/**
	 * 注册一次查找结束
	 * @param id    此次查找序列号
	 */
	public abstract void end(String id);
}
