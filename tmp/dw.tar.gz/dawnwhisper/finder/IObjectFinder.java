package dawnwhisper.finder;

import java.util.List;

/**
 * 测试控件查找接口,被测系统的引用
 * 
 * @author zhou
 *
 */
public interface IObjectFinder<T> {
	
    /**
     * 从某一根开始查找被测试对象，root为NULL时，从顶层开始查找
     * 
     * @param root      开始查找的根节点
     * @param findRule  查找规则
     * @return Object
     * @throws Throwable
     */
    T find(Object root,IFindRule ... findRules) throws Throwable;
    
    /**
     * 从最顶层查找对象
     * 
     * @param findRule
     * @return Object
     * @throws Throwable
     */
    T find(IFindRule ... findRules) throws Throwable;
    
    /**
     * 多结果查找，分层查找（模糊查询时排除非预期结果）
     * @param ifindrules   查找规则序列
     * @return List<T>     查找结果列表
     * @throws Throwable
     */
    List<T> findList(IFindRule ... ifindrules) throws Throwable;
    
    /**
     * 多结果查找，分层查找（模糊查询时排除非预期结果）
     * @param root         开始查找的根节点
     * @param ifindrules   查找规则序列
     * @return List<T>     查找结果列表
     * @throws Throwable
     */
    List<T> findList(Object root,IFindRule ... ifindrules) throws Throwable;
    
    /**
     * 设置查找监控接口
     * @param monitor   监控
     */
    void setFindMonitor(IFindMonitor monitor);
    
    /**
     * 设置执行监控接口
     * @param monitor   监控
     */
    void setExecMonitor(IExecMonitor monitor);
}
