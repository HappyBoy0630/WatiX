package dawnwhisper.finder;

/**
 * 查找规则的便捷使用接口
 * 
 * @author zhou
 *
 */
public final class By implements Consts{
	
	/**
	 * 如果控件有ID，只使用ID即可
	 * @param id         控件id
	 * @return IFindRule
	 */
	public static IFindRule id(String id){
		return new DefaultFindRule().id(id);
	}
	
	/**
	 * 没有ID的web控件，尽量使用tag加速定位过程
	 * @param tag         控件的tagName
	 * @return IFindRule
	 */
	public static IFindRule tag(String tag){
		return new DefaultFindRule().tag(tag);
	}
	
	/**
	 * 使用控件的class属性定位
	 * @param clazz        class属性值
	 * @return IFindRule
	 */
	public static IFindRule clazz(String clazz){
		return new DefaultFindRule().clazz(clazz);
	}
	
	/**
	 * 查找规则字符串
	 * @param ruleString
	 * @return IFindRule
	 */
	public static IFindRule by(String ruleString){
		if(ruleString == null || ruleString.indexOf("=") == -1 
				|| ruleString.indexOf(')') == -1){
			return null;
		}
		DefaultFindRule fr = new DefaultFindRule();
		try {
			String par[] = ruleString.split("\\),");
			for(String p : par){
				String pnv[] = p.split("=");
				if(pnv.length == 2){
					String pnvp[] = pnv[1].split("\\(");
					String pv = pnvp[0].trim();
					int pt = Integer.parseInt(pnvp[1].substring(0, 1));
					fr.addProperty(pnv[0].trim(), pv, pt);
				}
			}
		} catch (Throwable e) {
			return null;
		}
		if (fr.properties.size() > 0)
			return fr;
		return null;
	}
}
