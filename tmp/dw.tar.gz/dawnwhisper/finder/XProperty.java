package dawnwhisper.finder;

public class XProperty implements Consts{
	
    public String name = "";
    public String value = "";
    public int matchType = FULLMATCH;
    
    public int getMatchType() {
		return matchType;
	}

	public void setMatchType(int matchType) {
		this.matchType = matchType;
	}

	public XProperty(String name,String value){
        this.name = name;
        this.value = value;
    }
    
    public XProperty(String name,String value,int matchType){
        this.name = name;
        this.value = value;
        if(matchType == 0 || matchType == 1 || matchType == 2)
        	this.matchType = matchType;
    }
}
