package dawnwhisper.finder;

/**
 * 查找规则接口
 * 
 * @author zhou
 *
 */
public interface IFindRule extends Consts{
	
    /**
     * 获取所有查找 属性
     * 
     * @return XProperty[]
     */
    XProperty[] gets();
    
    /**
     * 判断规则中是否包含某个属性
     * @param propName  属性名
     * @return boolean
     */
    boolean has(String propName);
    
    /**
     * 获取规则中某个属性的值
     * @param propName 属性名
     * @return String
     */
    String get(String propName);
    
    /**
     * 在使用模糊匹配（XProperty.PATTERN）或部分匹配（XProperty.CONTAINS），
     * 或者使用未列出控件属性时 使用本方法
     * @param propName      属性名
     * @param propValue     属性值
     * @param matchType     匹配类型，见XProperty
     * @return IFindRule
     */
    public abstract IFindRule with(String propName,String propValue,int matchType);
    
    /**
     * 设置被查找控件的id属性值
     * @param id 控件的id属性
     * @return IFindRule
     */
    public abstract IFindRule id(String id);

    /**
     * 设置被查找控件的name属性值
     * @param name 控件的name属性
     * @return IFindRule
     */
    public abstract IFindRule name(String name);

    /**
     * 设置被查找控件（适用于HTML控件）的tag属性值
     * @param tag 控件的tag属性
     * @return IFindRule
     */
    public abstract IFindRule tag(String tag);

    /**
     * 设置被查找控件（只适用于link控件）的href属性值
     * @param href 控件的href属性
     * @return IFindRule
     */
    public abstract IFindRule href(String href);

    /**
     * 设置被查找控件的class属性值
     * @param clazz 控件的class属性
     * @return IFindRule
     */
    public abstract IFindRule clazz(String clazz);

    /**
     * 设置被查找控件（HTML）的content属性值
     * @param content 控件的content属性
     * @return IFindRule
     */
    public abstract IFindRule content(String content);
    
    /**
     * 设置被查找控件的父节点属性值
     * @param id 控件上层控件的id属性
     * @return IFindRule
     */
    public abstract IFindRule parent(String id);

    /**
     * 设置被查找控件所属（只适用于HTML）的frame属性值
     * @param frame 控件的frame属性
     * @return IFindRule
     */
    public abstract IFindRule frame(String frame);

    /**
     * 设置被查找控件的item属性值
     * @param item 控件的item属性
     * @return IFindRule
     */
    public abstract IFindRule item(int item);
    
    /**
     * 设置被查找控件的xpath属性值
     * @param xpath 控件的xpath属性
     * @return IFindRule
     */
    public abstract IFindRule xpath(String xpath);
}
