package dawnwhisper.finder;

public interface Consts {

	//-----------匹配类型------------
	public static final int PATTERN = 1;
	public static final int FULLMATCH = 0;
	public static final int CONTAINS = 2;
	
	//-----------查找属性------------
	String ID = "id";
	
	/**
	 * 被查找对象在查找结果中的index
	 */
	String ITEM = "item";
	
	/**
	 * Java中的类class名称，HTML中的CSS类名称
	 */
	String CLASS = "class";
	
	String XPATH = "xpath";
	String NAME = "name";
	
	/**
	 * HTML中个tagName
	 */
	String TAG = "tag";
	
	String HREF = "href";
	
	/**
	 * HTML中的节点的内容
	 */
	String CONTENT = "content";
	
	/**
	 * 被查找控件的上层（可以非直接父节点）控件ID，必须使用ID
	 */
	String PARENT = "parent";
	
	/**
	 * HTML中的frame/iframe的ID、Name或者src（全路径或部分路径）
	 */
	String FRAME = "frame";
	
}
