package dawnwhisper.waitfor.api;

public interface IAction {
    /**
     * 动作执行接口
     * @throws Throwable
     */
    public abstract void execute() throws Throwable;
}
