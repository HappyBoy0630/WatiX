package dawnwhisper.waitfor.api;

public interface ICheckAction extends ICheck{

    /**
     * 获取动作执行接口
     */
    public abstract IAction getAction();
    
}
