package dawnwhisper.waitfor.api;

@SuppressWarnings("serial")
public class TimeoutException extends Exception{

	public TimeoutException(String msg) {
        super(msg);
    }

}
