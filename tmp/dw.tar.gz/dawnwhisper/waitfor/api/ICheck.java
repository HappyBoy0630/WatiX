package dawnwhisper.waitfor.api;

/**
 * ICheck接口
 * 
 * @author zhou
 *
 */
public interface ICheck {
	
	/**
	 * 条件检查方法
	 * @return true/false
	 */
	public abstract boolean check() throws Throwable; 
}
