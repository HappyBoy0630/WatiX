package dawnwhisper.waitfor.impl;

import dawnwhisper.waitfor.api.IAction;
import dawnwhisper.waitfor.api.ICheck;
import dawnwhisper.waitfor.api.ICheckAction;

public class AND implements ICheckAction{

    private ICheck [] checkers = null;
    private IAction action = null;
    
    public AND(ICheck ... checkers){
        this.checkers = checkers;
    }
    
    public AND(IAction action,ICheck ... checkers){
        this.checkers = checkers;
        this.action = action;
    }
    
    @Override
    public boolean check() throws Throwable {
        
        if(checkers != null)
            for(ICheck checker : checkers){
                if(!checker.check()) return false;
            }
        
        return true;
    }

    @Override
    public IAction getAction() {
        return action;
    }

}
