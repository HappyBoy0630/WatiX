package dawnwhisper.waitfor.impl;

import dawnwhisper.waitfor.api.ICheck;
import dawnwhisper.waitfor.api.ICheckAction;

/**
 * OR逻辑
 * 多个逻辑组合成OR逻辑，执行check时，
 * 如果有逻辑a.check()==true,且a为ICheckAction接口时获取IAction并执行然后OR返回true，否则OR直接返回true；
 * 所有逻辑都不为true时，返回false。
 * 
 * @author zhou
 *
 */
public class OR implements ICheck{

    private ICheck[] iCheckActions = null;
    
    public OR(ICheck ... iCheckActions){
        this.iCheckActions = iCheckActions;
    }
    
    public static OR get(ICheck ... iCheckActions){
        return new OR(iCheckActions);
    }
    
    @Override
    public boolean check() throws Throwable{
        if(iCheckActions == null) return true;
        
        for(ICheck checker : iCheckActions){
            boolean check = checker.check();
            if(check){
				if (checker instanceof ICheckAction) {
					ICheckAction ica = (ICheckAction) checker;
					if(ica.getAction() != null){
	                    ica.getAction().execute();
	                }
				}
                
                return true;
            }
        }
        
        return false;
    }
  
}
