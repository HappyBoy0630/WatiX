package dawnwhisper.waitfor.impl;

import dawnwhisper.waitfor.api.IAction;
import dawnwhisper.waitfor.api.ICheck;
import dawnwhisper.waitfor.api.TimeoutException;

/**
 * 该类一般在控件封装的时候使用,完成循环尝试流程
 * 危险:loopAction有可能会因为操作控件查找不到而陷入长时间循环
 * 处理建议：loopAction应该判断控件是否存在,不存在则不执行动作
 * 
 * @author zhou
 *
 */
public class LOOP implements ICheck{

	private int loopTimes = 3;
    private ICheck expChecker = null;
    private IAction loopAction = null;
    private ICheck midChecker = null;
    
    private int innerLoopTimes = 0;
    
	public LOOP(ICheck midChecker,IAction loopAction,ICheck expChecker){
        this.midChecker = midChecker;
        this.loopAction = loopAction;
        this.expChecker = expChecker;
    }
    
    public static LOOP get(ICheck midChecker,IAction loopAction,ICheck expChecker){
        return new LOOP(midChecker,loopAction,expChecker);
    }
    
    public static LOOP get(ICheck midChecker,IAction loopAction,ICheck expChecker,int loop){
    	LOOP lp =new LOOP(midChecker,loopAction,expChecker);
    	lp.loopTimes = loop;
        return lp;
    }
    
    @Override
    public boolean check() throws Throwable {
    	
    	try {
    		if(expChecker == null) return true;
			WaitFor.waitFor(expChecker, WaitFor.getTryInterval());
			//target check OK,return true
			return true;
		} catch (TimeoutException e) {
		}
    	
		//target check fail,then midChecker.check
		boolean loop = false;
		if(midChecker != null)
			loop = midChecker.check();
		else
			loop = true;
		
        if(loop){
        	//midChecker OK means loopAction failed,try again and return false to loop
        	//this action has a long time execute risk(loopAction can not find the operator)
        	//so make sure the action try to find the operator just for once, or try limit times
        	if(loopTimes > 0 && innerLoopTimes > loopTimes){
        		throw new Exception("Try 3 times!");
        	}
        	innerLoopTimes++;
        	loopAction.execute();
            return false;
        }
        
        //midChecker fail then check target again
        return expChecker.check();
    }
}
