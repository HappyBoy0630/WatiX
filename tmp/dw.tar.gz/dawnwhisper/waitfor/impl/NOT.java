package dawnwhisper.waitfor.impl;

import dawnwhisper.waitfor.api.IAction;
import dawnwhisper.waitfor.api.ICheck;
import dawnwhisper.waitfor.api.ICheckAction;

public class NOT implements ICheckAction{

    private ICheck iCheck = null;
    private IAction action = null;
    
    public NOT(ICheck iCheck){
        this.iCheck = iCheck;
    }
    
    public NOT(ICheck iCheck,IAction action){
        this.iCheck = iCheck;
        this.action = action;
    }
    
    public static NOT get(ICheck iCheck){
        return new NOT(iCheck);
    }
    
    public static NOT get(ICheck iCheck,IAction action){
        return new NOT(iCheck,action);
    }
    
    @Override
    public boolean check() throws Throwable {
        if(iCheck == null) return true;
        return !iCheck.check();
    }

    @Override
    public IAction getAction() {
        return action;
    }
    
    @Override
    public String toString(){
        return "[WaitFor:NOT]" + iCheck.toString();
    }
    
}
