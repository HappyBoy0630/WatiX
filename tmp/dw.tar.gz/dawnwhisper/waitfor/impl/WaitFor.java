package dawnwhisper.waitfor.impl;

import dawnwhisper.waitfor.api.IAction;
import dawnwhisper.waitfor.api.ICheck;
import dawnwhisper.waitfor.api.ICheckAction;
import dawnwhisper.waitfor.api.TimeoutException;

public class WaitFor {
    
	public static final long DEFAULT_UI_TRYINTERVAL = 3000;
	private static int ui_action_delay = 200;
	private static boolean enableUIActionDelay = true;
	private static long tryInterval = DEFAULT_UI_TRYINTERVAL;
	private static boolean think = true;
	private static long thinkInterval = 20;
    
	public static int DEFAULT_TIMEOUT = 10 * 60 * 1000;
    
    public static void waitFor(ICheckAction iCheckAction) throws Throwable{
        waitFor(iCheckAction, DEFAULT_TIMEOUT);
    }
    
    public static void waitFor(ICheckAction iCheckAction,long timeout) throws Throwable{
    	waitFor(iCheckAction, timeout, -1);
    }
    
    public static void waitFor(ICheckAction iCheckAction,long timeout,long interval) throws Throwable{
        
        long end = System.currentTimeMillis() + timeout;
        
        while(true){
        	if(interval > 0) think(interval);
        	else if(think) think(thinkInterval);
            boolean check = iCheckAction.check();
			
            if(check){
                IAction action = iCheckAction.getAction();
                if(action != null){
                    action.execute();
                }
                break;
            }
            if(System.currentTimeMillis() > end){
                throw new TimeoutException("WaitFor " + iCheckAction.toString() + " Timeout!");
            }
        }

    }
    
    public static void waitFor(ICheck iCheck) throws Throwable{
        waitFor(iCheck, DEFAULT_TIMEOUT);
    }
    
    public static void waitFor(ICheck iCheck,long timeout) throws Throwable{
        waitFor(iCheck, timeout, -1);
    }
    
    public static void waitFor(ICheck iCheck,long timeout,long interval) throws Throwable{
        
        long end = System.currentTimeMillis() + timeout;
        
        while(true){
        	if(interval > 0) think(interval);
        	else if(think) think(thinkInterval);
            boolean check = iCheck.check();
			
            if(check){
                break;
            }
            if(System.currentTimeMillis() > end){
                throw new TimeoutException("WaitFor " + iCheck.toString() + " Timeout!");
            }
        }

    }
    
    private static final void think(long time){
    	try {Thread.sleep(time);} catch (InterruptedException e) {}
    }

    public static long getTryInterval() {
		return tryInterval;
	}

	/**
	 * 设置自动化执行时动作失败的下一次尝试间隔时间
	 * @param tryInterval   尝试间隔时间
	 */
	public static void setTryInterval(long tryInterval) {
		WaitFor.tryInterval = tryInterval;
	}
	
	public static final boolean think() {
		return think;
	}

	/**
	 * 设置WaitFor时两次条件检查之间是否加入思考时间（Sleep）
	 * @param think   是否加入思考时间
	 */
	public static void setThink(boolean think) {
		WaitFor.think = think;
	}
	
	/**
	 * 获取WaitFor时，think（两次条件检查的间隔）的时间长度，单位毫秒
	 * @return
	 */
	public static long getThinkInterval() {
		return thinkInterval;
	}

	/**
	 * 设置WaitFor时，think（两次条件检查的间隔）的时间长度，单位毫秒
	 * @param thinkInterval     时间长度（毫秒）
	 */
	public static void setThinkInterval(long thinkInterval) {
		WaitFor.thinkInterval = thinkInterval;
	}
	
	public void setUIActionDelayEnable(){
		enableUIActionDelay = true;
	}
	
	public void setUIActionDelayDisable(){
		enableUIActionDelay = true;
	}
	
	public final void uiActionDelay() {
		if (enableUIActionDelay)
			try {
				Thread.sleep(ui_action_delay);
			} catch (InterruptedException e) {
			}
	}
	
	public static int getUi_action_delay() {
		return ui_action_delay;
	}

	public static void setUi_action_delay(int ui_action_delay) {
		WaitFor.ui_action_delay = ui_action_delay;
	}
}
